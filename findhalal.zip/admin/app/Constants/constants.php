<?php
define('Status',array("Active","Inactive"));
define('oderStatus',array("Pending","Accepted","Cancelled","Delivered"));





