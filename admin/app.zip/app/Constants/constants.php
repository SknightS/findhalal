<?php
define('Status',array("Active","Inactive"));
define('User',array("ADMIN","MODERATOR"));
define('oderStatus',array("Pending","Accepted","Cancelled","Delivered"));





